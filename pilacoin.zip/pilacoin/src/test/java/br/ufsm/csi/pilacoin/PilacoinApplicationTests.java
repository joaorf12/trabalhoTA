package br.ufsm.csi.pilacoin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PilacoinApplicationTests {

	@Test
	void contextLoads() {
	}

}
